/*
 * Copyright 2012 Google Inc.
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

#include "SkInstCnt.h"

#if SK_ENABLE_INST_COUNT
bool gPrintInstCount = false;
#endif
